import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          about: path.resolve(__dirname, 'about.html'),
          privacy: path.resolve(__dirname, 'privacy.html'),
          blog: path.resolve(__dirname, 'blog.html'),
          'how-to-write-a-cv': path.resolve(__dirname, 'how-to-write-a-cv.html'),
          'resume-vs-cv': path.resolve(__dirname, 'resume-vs-cv.html'),
          'cover-letter-guide': path.resolve(__dirname, 'cover-letter-guide.html'),
          'best-resume-skills': path.resolve(__dirname, 'best-resume-skills.html'),
          'interview-tips': path.resolve(__dirname, 'interview-tips.html'),
          'professional-summary': path.resolve(__dirname, 'professional-summary.html'),
          'stand-out-cv': path.resolve(__dirname, 'stand-out-cv.html'),
          'cv-mistakes': path.resolve(__dirname, 'cv-mistakes.html'),
          'cv-no-experience': path.resolve(__dirname, 'cv-no-experience.html'),
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
